import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { estErreurReseau } from '../core/erreurs';
import { API, SessionService } from '../core/session.service';
import { STOCKAGE } from '../hors-ligne/stockage';
import { AbsenceVue, HistoriqueVue } from '../vie-scolaire/modeles-vs';
import {
  AppareilVue,
  BulletinEleveVue,
  CentreNotifications,
  ConfigurationPush,
  DeclarationVirement,
  EnfantVue,
  Lecture,
  MoyensParentVue,
  Operateur,
  PreferencesNotifications,
  SituationVue,
  TransactionVue,
  VirementParentVue,
} from './modeles-parent';

interface EnCache<T> {
  donnees: T;
  le: string;
}

/**
 * API de l'espace parent. Chaque lecture est gardée sur le téléphone : sur un réseau
 * faible ou coupé, le parent revoit la dernière situation connue, datée. Le cache est
 * effacé à la déconnexion, comme les listes de l'enseignant.
 */
@Injectable({ providedIn: 'root' })
export class ParentApi {
  private readonly http = inject(HttpClient);
  private readonly session = inject(SessionService);
  private readonly stockage = inject(STOCKAGE);

  private cle(nom: string): string {
    const p = this.session.profil();
    return `cache:${p?.utilisateurId ?? 'anonyme'}:${p?.etablissement?.id ?? 'aucun'}:parent:${nom}`;
  }

  /** Réseau d'abord ; sans réseau, la dernière copie gardée (sinon l'erreur). */
  private async lire<T>(chemin: string, nom: string): Promise<Lecture<T>> {
    const cle = this.cle(nom);
    try {
      const donnees = await firstValueFrom(this.http.get<T>(API + chemin));
      const le = new Date().toISOString();
      try {
        await this.stockage.ecrire<EnCache<T>>(cle, { donnees, le });
      } catch {
        // Le cache n'est qu'un secours
      }
      return { donnees, le, horsLigne: false };
    } catch (e) {
      if (estErreurReseau(e)) {
        const copie = await this.stockage.lire<EnCache<T>>(cle).catch(() => undefined);
        if (copie) {
          return { donnees: copie.donnees, le: copie.le, horsLigne: true };
        }
      }
      throw e;
    }
  }

  enfants(): Promise<Lecture<EnfantVue[]>> {
    return this.lire('/espace-parent/enfants', 'enfants');
  }

  absences(eleveId: string): Promise<Lecture<AbsenceVue[]>> {
    return this.lire(`/espace-parent/enfants/${eleveId}/absences`, `absences:${eleveId}`);
  }

  vieScolaire(eleveId: string): Promise<Lecture<HistoriqueVue[]>> {
    return this.lire(`/espace-parent/enfants/${eleveId}/vie-scolaire`, `vie-scolaire:${eleveId}`);
  }

  scolarite(eleveId: string): Promise<Lecture<SituationVue[]>> {
    return this.lire(`/espace-parent/enfants/${eleveId}/scolarite`, `scolarite:${eleveId}`);
  }

  bulletins(eleveId: string): Promise<Lecture<BulletinEleveVue[]>> {
    return this.lire(`/espace-parent/enfants/${eleveId}/bulletins`, `bulletins:${eleveId}`);
  }

  // ---------- En ligne uniquement

  bulletinPdf(id: string): Promise<Blob> {
    return firstValueFrom(this.http.get(`${API}/espace-parent/bulletins/${id}/pdf`, { responseType: 'blob' }));
  }

  recuPdf(paiementId: string): Promise<Blob> {
    return firstValueFrom(this.http.get(`${API}/espace-parent/paiements/${paiementId}/recu`, { responseType: 'blob' }));
  }

  payer(inscriptionId: string, d: { montant: number; operateur: Operateur; telephone: string; cleIdempotence: string }): Promise<TransactionVue> {
    return firstValueFrom(this.http.post<TransactionVue>(`${API}/espace-parent/inscriptions/${inscriptionId}/mobile-money`, d));
  }

  /** Moyens que l'établissement propose aux parents pour cette inscription (v0.38). */
  moyensPaiement(inscriptionId: string): Promise<MoyensParentVue> {
    return firstValueFrom(this.http.get<MoyensParentVue>(`${API}/espace-parent/inscriptions/${inscriptionId}/moyens-paiement`));
  }

  virements(inscriptionId: string): Promise<VirementParentVue[]> {
    return firstValueFrom(this.http.get<VirementParentVue[]>(`${API}/espace-parent/inscriptions/${inscriptionId}/virements`));
  }

  /** Déclaration d'un virement, avec sa preuve facultative (photo ou PDF de l'avis de la banque). */
  declarerVirement(inscriptionId: string, d: DeclarationVirement): Promise<VirementParentVue> {
    const donnees = new FormData();
    donnees.append('compteId', d.compteId);
    donnees.append('montant', String(d.montant));
    donnees.append('dateVirement', d.dateVirement);
    donnees.append('reference', d.reference);
    if (d.donneurOrdre) {
      donnees.append('donneurOrdre', d.donneurOrdre);
    }
    donnees.append('cleIdempotence', d.cleIdempotence);
    if (d.fichier) {
      donnees.append('fichier', d.fichier);
    }
    return firstValueFrom(this.http.post<VirementParentVue>(`${API}/espace-parent/inscriptions/${inscriptionId}/virements`, donnees));
  }

  transaction(id: string): Promise<TransactionVue> {
    return firstValueFrom(this.http.get<TransactionVue>(`${API}/espace-parent/mobile-money/${id}`));
  }

  /** Développement uniquement (profil dev du serveur) : joue la confirmation du parent sur son téléphone. */
  simulerConfirmation(id: string, accepter: boolean): Promise<TransactionVue> {
    return firstValueFrom(
      this.http.post<TransactionVue>(`${API}/simulateur/mobile-money/${id}`, null, {
        params: new HttpParams().set('accepter', accepter),
      }),
    );
  }

  // ---------- Notifications dans l'application (v0.50) : toujours en ligne

  centreNotifications(): Promise<CentreNotifications> {
    return firstValueFrom(this.http.get<CentreNotifications>(`${API}/espace-parent/notifications`));
  }

  marquerLues(ids: string[] = []): Promise<CentreNotifications> {
    return firstValueFrom(this.http.post<CentreNotifications>(`${API}/espace-parent/notifications/lues`, { ids }));
  }

  preferencesNotifications(): Promise<PreferencesNotifications> {
    return firstValueFrom(this.http.get<PreferencesNotifications>(`${API}/espace-parent/preferences-notifications`));
  }

  modifierPreferences(notifierRetards: boolean, discret: boolean): Promise<PreferencesNotifications> {
    return firstValueFrom(
      this.http.put<PreferencesNotifications>(`${API}/espace-parent/preferences-notifications`, { notifierRetards, discret }),
    );
  }

  configurationPush(): Promise<ConfigurationPush> {
    return firstValueFrom(this.http.get<ConfigurationPush>(`${API}/push/configuration`));
  }

  appareils(): Promise<AppareilVue[]> {
    return firstValueFrom(this.http.get<AppareilVue[]>(`${API}/push/abonnements`));
  }

  abonner(d: { endpoint: string; p256dh: string; auth: string; appareil: string }): Promise<AppareilVue[]> {
    return firstValueFrom(this.http.post<AppareilVue[]>(`${API}/push/abonnements`, d));
  }

  desabonner(endpoint: string): Promise<AppareilVue[]> {
    return firstValueFrom(this.http.post<AppareilVue[]>(`${API}/push/abonnements/retrait`, { endpoint }));
  }

  essaiPush(): Promise<{ appareils: number }> {
    return firstValueFrom(this.http.post<{ appareils: number }>(`${API}/push/essai`, null));
  }
}

/** Enregistre un fichier reçu du serveur sur le téléphone (bulletin, reçu). */
export function enregistrer(fichier: Blob, nom: string): void {
  const url = URL.createObjectURL(fichier);
  const lien = document.createElement('a');
  lien.href = url;
  lien.download = nom;
  document.body.appendChild(lien);
  lien.click();
  lien.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}
