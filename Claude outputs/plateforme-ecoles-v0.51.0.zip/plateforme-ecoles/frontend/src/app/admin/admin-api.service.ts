import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { Module, Role } from '../core/modeles';
import { API } from '../core/session.service';
import {
  AdoptionEtablissement,
  AdoptionPlateforme,
  AnneeVue,
  ClasseVue,
  CompteVue,
  DonneesResponsable,
  DossierEleveVue,
  DossierInscriptionVue,
  EleveVue,
  EspaceParentVue,
  EnseignantVue,
  EtablissementVue,
  ExportVue,
  FicheEnseignantVue,
  FiliereVue,
  InscriptionVue,
  InterimVue,
  LienExport,
  LigneDossierVue,
  LienParente,
  MatiereDeClasseVue,
  MatiereVue,
  ModeAdmission,
  ModuleEtablissementVue,
  MembreVue,
  Page,
  PeriodeVue,
  PieceVue,
  ProfilVue,
  RapportImport,
  ResultatAjoutMembre,
  ResultatCreationEtablissement,
  ResultatEngagement,
  ResultatReinitialisation,
  RapportStatistiques,
  SuiviEvaluationVue,
  Sexe,
  StatutBourse,
  StatutTenant,
  TypeEngagement,
  TypeMatiere,
  CategorieEnseignant,
} from './modeles-admin';

/** Appels de l'API pour l'espace d'administration (en ligne uniquement). */
@Injectable({ providedIn: 'root' })
export class AdminApi {
  private readonly http = inject(HttpClient);

  private get<T>(chemin: string, params?: Record<string, string | number | boolean>): Promise<T> {
    return firstValueFrom(this.http.get<T>(API + chemin, { params: params ? new HttpParams({ fromObject: params }) : undefined }));
  }

  private post<T>(chemin: string, corps: unknown = null): Promise<T> {
    return firstValueFrom(this.http.post<T>(API + chemin, corps));
  }

  private put<T>(chemin: string, corps: unknown): Promise<T> {
    return firstValueFrom(this.http.put<T>(API + chemin, corps));
  }

  private patch<T>(chemin: string, corps: unknown): Promise<T> {
    return firstValueFrom(this.http.patch<T>(API + chemin, corps));
  }

  private delete<T>(chemin: string): Promise<T> {
    return firstValueFrom(this.http.delete<T>(API + chemin));
  }

  // ---------- Plateforme (super administrateur)

  /** Tous les établissements, ou ceux qui dépendent d'une direction (à tout niveau). */
  etablissements(direction?: string | null): Promise<EtablissementVue[]> {
    return this.get('/plateforme/etablissements', direction ? { direction } : undefined);
  }

  rattacherEtablissement(id: string, directionId: string): Promise<EtablissementVue> {
    return this.put(`/plateforme/etablissements/${id}/rattachement`, { directionId });
  }

  creerEtablissement(d: {
    code: string;
    nom: string;
    telephoneAdministrateur: string;
    nomAdministrateur: string;
    prenomsAdministrateur: string;
    directionId?: string | null;
  }): Promise<ResultatCreationEtablissement> {
    return this.post('/plateforme/etablissements', d);
  }

  changerStatutEtablissement(id: string, statut: StatutTenant): Promise<EtablissementVue> {
    return this.patch(`/plateforme/etablissements/${id}/statut`, { statut });
  }

  // ---------- Membres

  membres(): Promise<MembreVue[]> {
    return this.get('/membres');
  }

  ajouterMembre(d: { telephone: string; nom: string; prenoms: string; role: Role }): Promise<ResultatAjoutMembre> {
    return this.post('/membres', d);
  }

  desactiverMembre(id: string): Promise<void> {
    return this.post(`/membres/${id}/desactivation`);
  }

  // ---------------- Parents et tuteurs (v0.29)

  ajouterResponsable(eleveId: string, d: DonneesResponsable): Promise<DossierEleveVue> {
    return this.post(`/eleves/${eleveId}/responsables`, d);
  }

  retirerResponsable(eleveId: string, responsableId: string): Promise<DossierEleveVue> {
    return this.delete(`/eleves/${eleveId}/responsables/${responsableId}`);
  }

  /** Canal des absences et retards : application (si activée) ou toujours par SMS (v0.50). */
  definirCanalNotification(responsableId: string, canal: 'AUTO' | 'SMS'): Promise<void> {
    return firstValueFrom(this.http.put<void>(`${API}/responsables/${responsableId}/canal-notification`, { canal }));
  }

  ouvrirEspaceParent(responsableId: string): Promise<EspaceParentVue> {
    return this.post(`/responsables/${responsableId}/espace-parent`);
  }

  /** Ouvre les comptes des parents d'une classe et renvoie la fiche de remise des accès (PDF ou Excel). */
  espacesParentsClasse(classeId: string, format: 'pdf' | 'xlsx'): Promise<HttpResponse<Blob>> {
    return firstValueFrom(this.http.post(`${API}/classes/${classeId}/espaces-parents`, null,
      { params: { format }, responseType: 'blob', observe: 'response' }));
  }

  // ---------------- Comptes (v0.27)

  comptes(): Promise<CompteVue[]> {
    return this.get('/comptes');
  }

  reinitialiserCompte(utilisateurId: string): Promise<ResultatReinitialisation> {
    return this.post(`/comptes/${utilisateurId}/reinitialisation`);
  }

  deverrouillerCompte(utilisateurId: string): Promise<CompteVue> {
    return this.post(`/comptes/${utilisateurId}/deverrouillage`);
  }

  /** Téléphone perdu ou volé : déconnecte (et fait effacer) les appareils du compte dans l'établissement (v0.32). */
  fermerAppareils(utilisateurId: string, effacer: boolean): Promise<{ appareils: number }> {
    return this.post(`/comptes/${utilisateurId}/appareils/fermeture`, { effacer });
  }

  modulesEtablissement(etablissementId: string): Promise<ModuleEtablissementVue[]> {
    return this.get(`/plateforme/etablissements/${etablissementId}/modules`);
  }

  definirModules(etablissementId: string, actifs: Module[]): Promise<ModuleEtablissementVue[]> {
    return firstValueFrom(this.http.put<ModuleEtablissementVue[]>(`${API}/plateforme/etablissements/${etablissementId}/modules`, { actifs }));
  }

  // ---------------- Mesure de l'adoption (v0.34)

  adoption(jours: number): Promise<AdoptionEtablissement> {
    return this.get('/adoption', { jours });
  }

  adoptionPlateforme(jours: number, direction?: string | null): Promise<AdoptionPlateforme> {
    return this.get('/plateforme/adoption', direction ? { jours, direction } : { jours });
  }

  /** Adoption vue du territoire (v0.39) : le ressort d'un compte de direction. */
  adoptionTerritoire(jours: number, direction?: string | null): Promise<AdoptionPlateforme> {
    return this.get('/pilotage/adoption', direction ? { jours, direction } : { jours });
  }

  recalculerAdoption(jours: number, direction?: string | null): Promise<AdoptionPlateforme> {
    const params: Record<string, string | number> = direction ? { jours, direction } : { jours };
    return firstValueFrom(this.http.post<AdoptionPlateforme>(`${API}/plateforme/adoption/calcul`, null, { params }));
  }

  // ---------------- Export complet des données (v0.33)
  // Sans établissement : celui de la session (administrateur) ; avec : super administrateur.

  exports(etablissementId?: string): Promise<ExportVue[]> {
    return this.get(cheminExports(etablissementId));
  }

  demanderExport(motDePasse: string, etablissementId?: string): Promise<ExportVue> {
    return this.post(cheminExports(etablissementId), { motDePasse });
  }

  lienExport(exportId: string, etablissementId?: string): Promise<LienExport> {
    return this.post(`${cheminExports(etablissementId)}/${exportId}/lien`);
  }

  administrateursEtablissement(etablissementId: string): Promise<CompteVue[]> {
    return this.get(`/plateforme/etablissements/${etablissementId}/administrateurs`);
  }

  reinitialiserAdministrateur(etablissementId: string, utilisateurId: string): Promise<ResultatReinitialisation> {
    return this.post(`/plateforme/etablissements/${etablissementId}/administrateurs/${utilisateurId}/reinitialisation`);
  }

  // ---------- Profils, années, périodes

  profils(): Promise<ProfilVue[]> {
    return this.get('/profils');
  }

  initialiserProfils(): Promise<ProfilVue[]> {
    return this.post('/profils/initialisation');
  }

  annees(): Promise<AnneeVue[]> {
    return this.get('/annees');
  }

  creerAnnee(d: { libelle: string; debut: string; fin: string }): Promise<AnneeVue> {
    return this.post('/annees', d);
  }

  ouvrirAnnee(id: string): Promise<AnneeVue> {
    return this.post(`/annees/${id}/ouverture`);
  }

  periodes(anneeId: string): Promise<PeriodeVue[]> {
    return this.get(`/annees/${anneeId}/periodes`);
  }

  genererPeriodes(anneeId: string, profilId: string): Promise<PeriodeVue[]> {
    return this.post(`/annees/${anneeId}/periodes/generation`, { profilId });
  }

  // ---------- Filières et matières

  filieres(): Promise<FiliereVue[]> {
    return this.get('/filieres');
  }

  creerFiliere(d: { code: string; libelle: string; cycle: string; diplomeVise: string | null; profilId: string }): Promise<FiliereVue> {
    return this.post('/filieres', d);
  }

  matieres(): Promise<MatiereVue[]> {
    return this.get('/matieres');
  }

  creerMatiere(d: { code: string; libelle: string; type: TypeMatiere }): Promise<MatiereVue> {
    return this.post('/matieres', d);
  }

  // ---------- Classes et programmes

  classes(anneeId: string): Promise<ClasseVue[]> {
    return this.get(`/annees/${anneeId}/classes`);
  }

  classe(id: string): Promise<ClasseVue> {
    return this.get(`/classes/${id}`);
  }

  creerClasse(anneeId: string, d: { filiereId: string; code: string; niveau: string; effectifMax: number | null }): Promise<ClasseVue> {
    return this.post(`/annees/${anneeId}/classes`, d);
  }

  supprimerClasse(id: string): Promise<void> {
    return this.delete(`/classes/${id}`);
  }

  matieresDeClasse(classeId: string): Promise<MatiereDeClasseVue[]> {
    return this.get(`/classes/${classeId}/matieres`);
  }

  /** Volume horaire annuel du référentiel, reporté sur les classes d'une filière et d'un niveau (v0.50). */
  appliquerVolumeAnnuel(
    anneeId: string,
    d: { filiereId: string; niveau: string | null; matiereId: string; volumeAnnuel: number },
  ): Promise<{ classes: number }> {
    return firstValueFrom(this.http.put<{ classes: number }>(`${API}/annees/${anneeId}/volumes-annuels`, d));
  }

  definirMatiere(
    classeId: string,
    matiereId: string,
    d: { coefficient: number; groupe: string | null; volumeHebdo: number | null; volumeTotal: number | null },
  ): Promise<MatiereDeClasseVue> {
    return this.put(`/classes/${classeId}/matieres/${matiereId}`, d);
  }

  retirerMatiere(classeId: string, matiereId: string): Promise<void> {
    return this.delete(`/classes/${classeId}/matieres/${matiereId}`);
  }

  affecter(classeId: string, matiereId: string, engagementId: string): Promise<MatiereDeClasseVue> {
    return this.put(`/classes/${classeId}/matieres/${matiereId}/enseignant`, { engagementId });
  }

  retirerAffectation(classeId: string, matiereId: string): Promise<MatiereDeClasseVue> {
    return this.delete(`/classes/${classeId}/matieres/${matiereId}/enseignant`);
  }

  // ---------- Élèves et inscriptions

  eleves(q: string, page: number, taille = 20): Promise<Page<EleveVue>> {
    return this.get('/eleves', { q, page, taille });
  }

  dossier(eleveId: string): Promise<DossierEleveVue> {
    return this.get(`/eleves/${eleveId}`);
  }

  creerEleve(d: {
    nom: string;
    prenoms: string;
    sexe: Sexe;
    dateNaissance: string;
    lieuNaissance: string | null;
    responsables: { nom: string; prenoms: string; telephone: string; lien: LienParente }[];
  }): Promise<DossierEleveVue> {
    return this.post('/eleves', d);
  }

  inscrire(d: {
    eleveId: string;
    classeId: string;
    redoublant: boolean;
    statutBourse: StatutBourse | null;
    modeAdmission?: ModeAdmission | null;
  }): Promise<InscriptionVue> {
    return this.post('/inscriptions', d);
  }

  /** Répartition (v0.47) : le censeur dans un même niveau, le chef d'établissement partout. */
  changerClasse(inscriptionId: string, classeId: string): Promise<InscriptionVue> {
    return this.patch(`/inscriptions/${inscriptionId}/classe`, { classeId });
  }

  // ---------- Dossier d'inscription (v0.47)

  piecesDossier(): Promise<PieceVue[]> {
    return this.get('/pieces-dossier');
  }

  definirPieces(pieces: { id: string | null; libelle: string; modes: ModeAdmission[]; obligatoire: boolean }[]): Promise<PieceVue[]> {
    return this.put('/pieces-dossier', pieces);
  }

  dossierInscription(inscriptionId: string): Promise<DossierInscriptionVue> {
    return this.get(`/inscriptions/${inscriptionId}/dossier`);
  }

  enregistrerDossier(inscriptionId: string, modeAdmission: ModeAdmission | null, piecesRecues: string[]): Promise<DossierInscriptionVue> {
    return this.put(`/inscriptions/${inscriptionId}/dossier`, { modeAdmission, piecesRecues });
  }

  dossiersInscription(anneeId: string, incomplets: boolean): Promise<LigneDossierVue[]> {
    return this.get(`/annees/${anneeId}/dossiers-inscription`, { incomplets });
  }

  // ---------- Intérim du chef d'établissement (v0.47)

  interims(): Promise<InterimVue[]> {
    return this.get('/interims');
  }

  designerInterim(d: { utilisateurId: string; du: string; au: string; motif: string }): Promise<InterimVue> {
    return this.post('/interims', d);
  }

  terminerInterim(id: string): Promise<InterimVue> {
    return this.post(`/interims/${id}/fin`);
  }

  inscriptions(classeId: string): Promise<InscriptionVue[]> {
    return this.get(`/classes/${classeId}/inscriptions`);
  }

  /** Modèle Excel d'import, avec la liste des classes de l'année. */
  async modeleImport(anneeId: string): Promise<Blob> {
    return firstValueFrom(this.http.get(`${API}/annees/${anneeId}/eleves/import/modele`, { responseType: 'blob' }));
  }

  importer(anneeId: string, fichier: File, simulation: boolean): Promise<RapportImport> {
    const donnees = new FormData();
    donnees.append('fichier', fichier);
    return firstValueFrom(
      this.http.post<RapportImport>(`${API}/annees/${anneeId}/eleves/import`, donnees, {
        params: new HttpParams().set('simulation', simulation),
      }),
    );
  }

  // ---------- Enseignants

  enseignants(): Promise<EnseignantVue[]> {
    return this.get('/enseignants');
  }

  engager(d: {
    telephone: string;
    nom: string;
    prenoms: string;
    sexe: Sexe;
    specialite: string | null;
    type: TypeEngagement;
    debut: string;
    fin: string | null;
    tauxHoraire: number | null;
    categorie?: CategorieEnseignant;
  }): Promise<ResultatEngagement> {
    return this.post('/enseignants', d);
  }

  /** Général ou technique et professionnel (v0.40) : seul ce dernier voit les ateliers. */
  classerEnseignant(engagementId: string, categorie: CategorieEnseignant): Promise<EnseignantVue> {
    return this.put(`/engagements/${engagementId}/categorie`, { categorie });
  }

  /** Fiche : matières assurées pendant l'année active et charge hebdomadaire. */
  ficheEnseignant(engagementId: string): Promise<FicheEnseignantVue> {
    return this.get(`/engagements/${engagementId}`);
  }

  /** Date passée : fin immédiate ; aujourd'hui ou plus tard : fin programmée. */
  terminerEngagement(engagementId: string, date: string, motif: string | null): Promise<EnseignantVue> {
    return this.post(`/engagements/${engagementId}/fin`, { date, motif });
  }

  annulerFinEngagement(engagementId: string): Promise<EnseignantVue> {
    return this.delete(`/engagements/${engagementId}/fin`);
  }

  annulerInvitation(engagementId: string): Promise<void> {
    return this.delete(`/engagements/${engagementId}`);
  }

  // ---------- Suivi des évaluations

  /** `ordre` : 1er, 2e… trimestre ou semestre ; absent : toute l'année. */
  suiviEvaluations(anneeId: string, ordre?: number): Promise<SuiviEvaluationVue[]> {
    return this.get(`/annees/${anneeId}/suivi-evaluations`, ordre ? { ordre } : undefined);
  }

  statistiques(anneeId: string): Promise<RapportStatistiques> {
    return this.get(`/annees/${anneeId}/statistiques`);
  }

  classeurStatistiques(anneeId: string): Promise<Blob> {
    return firstValueFrom(this.http.get(`${API}/annees/${anneeId}/statistiques/excel`, { responseType: 'blob' }));
  }
}

function cheminExports(etablissementId?: string): string {
  return etablissementId ? `/plateforme/etablissements/${etablissementId}/exports` : '/exports';
}
