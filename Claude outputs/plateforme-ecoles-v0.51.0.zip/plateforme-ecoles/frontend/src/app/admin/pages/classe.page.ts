import { VignetteComponent } from '../../partage/photo-identite.component';
import { PhotosApi } from '../../partage/photos-api.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, input, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { dateCourte } from '../../core/outils';
import { filtrer } from '../../core/recherche';
import { SessionService } from '../../core/session.service';
import { RechercheComponent } from '../../partage/recherche.component';
import { Action } from '../action';
import { AdminApi } from '../admin-api.service';
import { AdminNavComponent } from '../admin-nav.component';
import { nomDuFichier } from '../../ateliers/export-boutons.component';
import { enregistrerFichier } from '../../scolarite/scolarite-api.service';
import {
  ClasseVue,
  EnseignantVue,
  InscriptionVue,
  LIBELLE_TYPE_MATIERE,
  MatiereDeClasseVue,
  MatiereVue,
  ProfilVue,
} from '../modeles-admin';

/** Brouillon d'une ligne du programme, modifiée avant enregistrement. */
interface Brouillon {
  coefficient: number;
  groupe: string;
  volumeHebdo: number | null;
  volumeTotal: number | null;
}

const GROUPES_PROPOSES = ['Matières générales', 'Matières techniques', 'Matières professionnelles'];

/** Une classe : son programme (matières, coefficients, enseignants) et ses élèves. */
@Component({
  selector: 'app-classe',
  imports: [FormsModule, RouterLink, AdminNavComponent, RechercheComponent, VignetteComponent],
  templateUrl: './classe.page.html',
  styles: `
    .comptes-parents {
      margin-top: 1rem;
      padding-top: 0.75rem;
      border-top: 1px solid var(--bordure);
      h3 {
        font-size: 1rem;
        margin: 0 0 0.4rem;
      }
    }
    .ajout {
      border-top: 1px solid var(--bordure);
      margin-top: 1rem;
      padding-top: 0.5rem;
    }
    h3 {
      font-size: 1rem;
      margin: 0.5rem 0 0.75rem;
    }
    .court {
      width: 5.5rem;
    }
    .moyen {
      width: 12rem;
    }
    td.photo {
      width: 40px;
      padding-block: 0.2rem;
    }
  `,
})
export class ClassePage implements OnInit {
  readonly id = input.required<string>();

  private readonly api = inject(AdminApi);
  private readonly router = inject(Router);
  private readonly session = inject(SessionService);
  private readonly photos = inject(PhotosApi);

  protected readonly types = LIBELLE_TYPE_MATIERE;
  protected readonly dateCourte = dateCourte;
  protected readonly groupesProposes = GROUPES_PROPOSES;
  protected readonly action = new Action();
  protected readonly classe = signal<ClasseVue | null>(null);
  protected readonly profil = signal<ProfilVue | null>(null);
  protected readonly programme = signal<MatiereDeClasseVue[]>([]);
  protected readonly matieres = signal<MatiereVue[]>([]);
  protected readonly enseignants = signal<EnseignantVue[]>([]);
  protected readonly eleves = signal<InscriptionVue[]>([]);
  /** Élèves qui ont une photo d'identité (v0.44) : seules leurs miniatures sont demandées. */
  protected readonly avecPhoto = signal<Set<string>>(new Set());
  protected readonly actionCartes = new Action();
  protected readonly brouillons = signal<Record<string, Brouillon>>({});
  protected readonly enregistre = signal<string | null>(null);
  protected readonly reporte = signal<string | null>(null);

  protected readonly peutModifier = computed(() => this.session.aLeRole('ADMIN_ECOLE', 'CENSEUR'));
  /** Saisie des dossiers (inscription, photo) : l'intendance et le chef d'établissement (v0.47). */
  protected readonly saisie = computed(() => this.session.aLeRole('ADMIN_ECOLE', 'INTENDANT'));
  /** Documents remis aux familles : cartes scolaires, comptes des parents. */
  protected readonly documents = computed(() => this.session.aLeRole('ADMIN_ECOLE', 'INTENDANT', 'SECRETARIAT'));
  /** Répartition des élèves entre les classes : le censeur (même niveau), le chef d'établissement. */
  protected readonly peutRepartir = computed(() => this.session.aLeRole('ADMIN_ECOLE', 'CENSEUR'));
  protected readonly estChef = computed(() => this.session.aLeRole('ADMIN_ECOLE'));
  protected readonly repartition = signal(false);
  protected readonly classesCibles = signal<ClasseVue[]>([]);
  protected readonly cibles = signal<Record<string, string>>({});
  protected readonly messageRepartition = signal<string | null>(null);
  protected readonly espaceParent = this.session.moduleActif('ESPACE_PARENT');
  protected readonly actionParents = new Action();
  protected readonly confirmationParents = signal(false);
  protected readonly messageParents = signal<string | null>(null);
  protected readonly groupesObligatoires = computed(() => this.profil()?.modele === 'NOTES_PAR_GROUPES');
  protected readonly volumeTotalObligatoire = computed(() => this.profil()?.decoupage === 'MODULE');
  protected readonly matieresDisponibles = computed(() => {
    const dans = new Set(this.programme().map((m) => m.matiereId));
    return this.matieres().filter((m) => m.actif && !dans.has(m.id));
  });
  protected readonly filtreEleves = signal('');
  protected readonly elevesAffiches = computed(() =>
    filtrer(
      this.eleves().map((e, i) => ({ ...e, rang: i + 1 })),
      this.filtreEleves(),
      (e) => [e.nom, e.prenoms, e.matricule],
    ),
  );
  protected readonly enseignantsActifs = computed(() =>
    this.enseignants()
      .filter((e) => e.statut === 'ACTIF')
      .sort((a, b) => (a.nom ?? '').localeCompare(b.nom ?? '')),
  );
  protected readonly chargeHebdo = computed(() =>
    this.programme().reduce((total, m) => total + (Number(m.volumeHebdo) || 0), 0),
  );
  protected readonly sansEnseignant = computed(() => this.programme().filter((m) => !m.engagementId).length);

  // Nouvelle matière
  protected readonly nMatiere = signal('');
  protected readonly nCoefficient = signal<number>(1);
  protected readonly nGroupe = signal('');
  protected readonly nVolumeHebdo = signal<number | null>(null);
  protected readonly nVolumeTotal = signal<number | null>(null);

  async ngOnInit(): Promise<void> {
    await this.action.executer(async () => {
      const classe = await this.api.classe(this.id());
      this.classe.set(classe);
      const [profils, programme, matieres, enseignants, eleves] = await Promise.all([
        this.api.profils(),
        this.api.matieresDeClasse(classe.id),
        this.api.matieres(),
        this.api.enseignants().catch(() => [] as EnseignantVue[]),
        this.api.inscriptions(classe.id),
      ]);
      this.profil.set(profils.find((p) => p.id === classe.profilId) ?? null);
      this.majProgramme(programme);
      this.matieres.set([...matieres].sort((a, b) => a.libelle.localeCompare(b.libelle)));
      this.enseignants.set(enseignants);
      this.eleves.set(eleves);
    });
    const c = this.classe();
    if (c) {
      this.avecPhoto.set(new Set(await this.photos.elevesAvecPhoto(c.id).catch(() => [] as string[])));
    }
  }

  /** Cartes d'identité scolaires de la classe, huit par page A4 (v0.44). */
  protected async cartesScolaires(): Promise<void> {
    const c = this.classe();
    if (!c) {
      return;
    }
    const pdf = await this.actionCartes.executer(async () => {
      try {
        return await this.photos.cartesClasse(c.id);
      } catch (e) {
        throw await problemeDepuisBlob(e);
      }
    });
    if (pdf) {
      enregistrerFichier(pdf, `cartes-scolaires-${c.code}.pdf`);
    }
  }

  private majProgramme(programme: MatiereDeClasseVue[]): void {
    const tries = [...programme].sort(
      (a, b) => (a.groupe ?? '').localeCompare(b.groupe ?? '') || a.matiereLibelle.localeCompare(b.matiereLibelle),
    );
    this.programme.set(tries);
    this.brouillons.set(
      Object.fromEntries(
        tries.map((m) => [
          m.matiereId,
          { coefficient: Number(m.coefficient), groupe: m.groupe ?? '', volumeHebdo: m.volumeHebdo, volumeTotal: m.volumeTotal },
        ]),
      ),
    );
  }

  protected brouillon(m: MatiereDeClasseVue): Brouillon {
    return this.brouillons()[m.matiereId];
  }

  protected modifier(m: MatiereDeClasseVue, champ: keyof Brouillon, valeur: string): void {
    const nombre = valeur === '' ? null : Number(valeur);
    this.brouillons.update((b) => ({
      ...b,
      [m.matiereId]: { ...b[m.matiereId], [champ]: champ === 'groupe' ? valeur : nombre },
    }));
  }

  protected modifiee(m: MatiereDeClasseVue): boolean {
    const b = this.brouillon(m);
    return (
      b.coefficient !== Number(m.coefficient) ||
      b.groupe !== (m.groupe ?? '') ||
      b.volumeHebdo !== (m.volumeHebdo === null ? null : Number(m.volumeHebdo)) ||
      b.volumeTotal !== (m.volumeTotal === null ? null : Number(m.volumeTotal))
    );
  }

  protected async enregistrer(m: MatiereDeClasseVue): Promise<void> {
    const b = this.brouillon(m);
    const r = await this.action.executer(() =>
      this.api.definirMatiere(this.id(), m.matiereId, {
        coefficient: b.coefficient,
        groupe: b.groupe.trim() || null,
        volumeHebdo: b.volumeHebdo,
        volumeTotal: b.volumeTotal,
      }),
    );
    if (r) {
      this.majProgramme(this.programme().map((x) => (x.matiereId === r.matiereId ? r : x)));
      this.enregistre.set(m.matiereLibelle);
    }
  }

  /** Reporte le volume annuel sur toutes les classes de la même filière et du même niveau (v0.50). */
  protected async reporter(m: MatiereDeClasseVue): Promise<void> {
    const c = this.classe();
    if (!c || m.volumeTotal === null) {
      return;
    }
    this.reporte.set(null);
    const r = await this.action.executer(() =>
      this.api.appliquerVolumeAnnuel(c.anneeId, {
        filiereId: c.filiereId,
        niveau: c.niveau,
        matiereId: m.matiereId,
        volumeAnnuel: Number(m.volumeTotal),
      }),
    );
    if (r) {
      this.reporte.set(`${m.matiereLibelle} : ${m.volumeTotal} h par an reportées sur ${r.classes} classe(s) de ${c.filiereCode} ${c.niveau}.`);
    }
  }

  protected async affecter(m: MatiereDeClasseVue, engagementId: string): Promise<void> {
    const r = await this.action.executer(() =>
      engagementId ? this.api.affecter(this.id(), m.matiereId, engagementId) : this.api.retirerAffectation(this.id(), m.matiereId),
    );
    if (r) {
      this.majProgramme(this.programme().map((x) => (x.matiereId === r.matiereId ? r : x)));
    } else {
      // Refus du serveur : on remet la liste comme avant
      this.majProgramme([...this.programme()]);
    }
  }

  protected async retirer(m: MatiereDeClasseVue): Promise<void> {
    if (!window.confirm(`Retirer ${m.matiereLibelle} du programme de la classe ?`)) {
      return;
    }
    if (await this.action.reussit(() => this.api.retirerMatiere(this.id(), m.matiereId))) {
      this.majProgramme(this.programme().filter((x) => x.matiereId !== m.matiereId));
    }
  }

  protected async ajouter(): Promise<void> {
    const r = await this.action.executer(() =>
      this.api.definirMatiere(this.id(), this.nMatiere(), {
        coefficient: this.nCoefficient(),
        groupe: this.nGroupe().trim() || null,
        volumeHebdo: this.nVolumeHebdo(),
        volumeTotal: this.nVolumeTotal(),
      }),
    );
    if (r) {
      this.majProgramme([...this.programme(), r]);
      this.nMatiere.set('');
      this.nVolumeHebdo.set(null);
      this.nVolumeTotal.set(null);
    }
  }

  protected nomEnseignant(engagementId: string | null): string {
    const e = this.enseignants().find((x) => x.engagementId === engagementId);
    return e ? `${e.nom} ${e.prenoms}` : '';
  }

  protected async supprimer(): Promise<void> {
    const c = this.classe();
    if (!c || !window.confirm(`Supprimer la classe ${c.code} ?`)) {
      return;
    }
    if (await this.action.reussit(() => this.api.supprimerClasse(c.id))) {
      await this.router.navigate(['/admin/classes']);
    }
  }

  /** Ouvre les comptes des parents de la classe et télécharge la fiche de remise des accès. */
  protected async ouvrirComptesParents(format: 'pdf' | 'xlsx'): Promise<void> {
    const c = this.classe();
    if (!c) {
      return;
    }
    this.messageParents.set(null);
    const r = await this.actionParents.executer(async () => {
      try {
        return await this.api.espacesParentsClasse(c.id, format);
      } catch (e) {
        throw await problemeDepuisBlob(e);
      }
    });
    this.confirmationParents.set(false);
    if (r?.body) {
      enregistrerFichier(r.body, nomDuFichier(r.headers.get('Content-Disposition'), `acces-parents-${c.code}.${format}`));
      this.messageParents.set('Comptes des parents ouverts : la fiche de remise des accès est téléchargée.');
    }
  }
  // ---------- Répartition (v0.47)

  protected async ouvrirRepartition(): Promise<void> {
    const c = this.classe();
    if (!c) {
      return;
    }
    const toutes = await this.action.executer(() => this.api.classes(c.anneeId));
    if (toutes) {
      const chef = this.session.aLeRole('ADMIN_ECOLE');
      this.classesCibles.set(
        toutes.filter((x) => x.id !== c.id && (chef || x.niveau === c.niveau)).sort((a, b) => a.code.localeCompare(b.code)),
      );
      this.repartition.set(true);
    }
  }

  protected choisirCible(inscriptionId: string, classeId: string): void {
    this.cibles.set({ ...this.cibles(), [inscriptionId]: classeId });
  }

  protected async deplacer(e: InscriptionVue): Promise<void> {
    const cible = this.cibles()[e.id];
    if (!cible) {
      return;
    }
    this.messageRepartition.set(null);
    const apres = await this.action.executer(() => this.api.changerClasse(e.id, cible));
    if (apres) {
      this.eleves.set(this.eleves().filter((x) => x.id !== e.id));
      this.messageRepartition.set(`${e.prenoms} ${e.nom} passe en ${apres.classeCode}.`);
    }
  }
}

/** Une erreur sur un téléchargement arrive en Blob : on relit le problème JSON du serveur. */
async function problemeDepuisBlob(e: unknown): Promise<unknown> {
  if (e instanceof HttpErrorResponse && e.error instanceof Blob) {
    try {
      return new HttpErrorResponse({ error: JSON.parse(await e.error.text()), status: e.status, statusText: e.statusText });
    } catch {
      return e;
    }
  }
  return e;
}
