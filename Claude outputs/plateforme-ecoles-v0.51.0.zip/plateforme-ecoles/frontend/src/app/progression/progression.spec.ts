import { HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnneeCourante } from '../admin/annee-courante.service';
import { Role } from '../core/modeles';
import { SessionService } from '../core/session.service';
import { attendre, configurer, reponse } from '../testing/outils-test';
import { erreurFiche, libelleMois, lireHeures, moisCourant } from './modeles-progression';
import { CahierLecturePage } from './pages/cahier-lecture.page';
import { CahiersVisasPage } from './pages/cahiers-visas.page';
import { FicheProgressionPage } from './pages/fiche-progression.page';
import { MesProgressionsPage } from './pages/mes-progressions.page';
import { SuiviProgressionsPage } from './pages/suivi-progressions.page';

const ANNEE = { id: 'a1', libelle: '2026-2027', debut: '2026-10-01', fin: '2027-07-31', etat: 'ACTIVE' };
const URL_FICHE = '/api/v1/classes/c1/matieres/m-elec/progression';

async function session(http: HttpTestingController, role: Role, annees = false): Promise<void> {
  const etab = { id: 'etab-1', code: 'LTK', nom: 'Lycée technique', roles: [role] };
  const connexion = TestBed.inject(SessionService).connexion('61000001', 'secret123');
  http.expectOne('/api/v1/auth/connexion').flush(reponse('u5', 1, { etablissementActif: etab, etablissements: [etab] }));
  await attendre();
  http.expectOne('/api/v1/moi').flush({ nom: 'SANOU', prenoms: 'Paul' });
  await connexion;
  if (annees) {
    const a = TestBed.inject(AnneeCourante).charger();
    http.expectOne('/api/v1/annees').flush([ANNEE]);
    await a;
  }
}

function texte<T>(f: ComponentFixture<T>): string {
  f.detectChanges();
  return ((f.nativeElement as HTMLElement).textContent ?? '').replace(/\s+/g, ' ');
}

function bouton<T>(f: ComponentFixture<T>, libelle: string): HTMLButtonElement {
  f.detectChanges();
  const b = [...(f.nativeElement as HTMLElement).querySelectorAll('button')].find((x) => x.textContent?.trim().startsWith(libelle));
  if (!b) {
    throw new Error(`Bouton « ${libelle} » introuvable`);
  }
  return b;
}

async function saisir<T>(f: ComponentFixture<T>, selecteur: string, valeur: string): Promise<void> {
  f.detectChanges();
  await attendre();
  const champ = (f.nativeElement as HTMLElement).querySelector(selecteur) as HTMLInputElement | HTMLTextAreaElement;
  champ.value = valeur;
  champ.dispatchEvent(new Event('input'));
  f.detectChanges();
}

function fiche(autres: object = {}) {
  return {
    id: null, classeId: 'c1', classeCode: '2nde F3', matiereId: 'm-elec', matiereCode: 'ELEC', matiereLibelle: 'Électrotechnique',
    type: 'TECHNIQUE', domaine: 'TECHNIQUE', engagementId: 'g1', enseignant: 'SANOU Paul', statut: null, sequences: [],
    heuresPrevues: 0, volumeHebdo: 4, volumeTotal: null, modifieeLe: null, soumiseLe: null, viseLe: null, visePar: null,
    commentaireVisa: null, auteur: true, modifiable: true, visable: false,
    avancement: { heuresRealisees: 0, heuresHorsSequence: 0, seances: 0, derniereSeance: null },
    ...autres,
  };
}

const ligne = (classe: string, matiere: string, statut: string | null, sequences = 0) => ({
  classeId: classe, classeCode: classe, niveau: '2nde', matiereId: 'm-' + matiere, matiereCode: matiere, matiereLibelle: matiere,
  type: 'TECHNIQUE', domaine: 'TECHNIQUE', engagementId: 'g1', enseignant: 'SANOU Paul', statut, sequences,
  heuresPrevues: sequences * 10, volumeHebdo: 4, soumiseLe: null, viseLe: null,
  avancement: { heuresRealisees: sequences * 4, heuresHorsSequence: 0, seances: sequences, derniereSeance: sequences ? '2026-10-02' : null },
});

describe('Fiches de progression', () => {
  let http: HttpTestingController;

  beforeEach(() => {
    ({ http } = configurer());
  });

  afterEach(() => http.verify());

  it('contrôle les séquences avant l’envoi', () => {
    expect(lireHeures('12,5')).toBe(12.5);
    expect(lireHeures('12.25')).toBeNull();
    expect(lireHeures('0')).toBeNull();
    const s = { titre: 'Lois', contenu: '', competences: '', heures: '10', semaineDebut: '' };
    expect(erreurFiche([s])).toBeNull();
    expect(erreurFiche([s, { ...s, titre: ' ' }])).toBe('Séquence 2 : donnez un titre.');
    expect(erreurFiche([{ ...s, heures: 'dix' }])).toContain('heures prévues');
  });

  it('enseignant : liste de ses fiches, renvoi signalé', async () => {
    await session(http, 'ENSEIGNANT');
    const f = TestBed.createComponent(MesProgressionsPage);
    f.detectChanges();
    await attendre();
    http.expectOne('/api/v1/espace-enseignant/progressions').flush([ligne('2nde F3', 'ELEC', 'A_REVOIR', 3), ligne('1re F3', 'DESSIN', null)]);
    await attendre();
    const t = texte(f);
    expect(t).toContain('1 progression(s) renvoyée(s)');
    expect(t).toContain('3 séquence(s) · 12 h faites / 30 h prévues');
    expect(t).toContain('Non commencée');
    expect(t).toContain('À revoir');
  });

  it('enseignant : prépare la première séquence et soumet au chef des travaux', async () => {
    await session(http, 'ENSEIGNANT');
    const f = TestBed.createComponent(FicheProgressionPage);
    f.componentRef.setInput('classeId', 'c1');
    f.componentRef.setInput('matiereId', 'm-elec');
    f.detectChanges();
    await attendre();
    http.expectOne(URL_FICHE).flush(fiche());
    await attendre();
    expect(texte(f)).toContain('visa du chef des travaux');
    expect(bouton(f, 'Soumettre au visa').disabled).toBe(true); // séquence vide

    await saisir(f, '#titre-0', 'Lois de l’électricité');
    await saisir(f, '#heures-0', '12,5');
    await saisir(f, '#contenu-0', 'Loi d’Ohm');
    expect(texte(f)).toContain('1 séquence(s) · 12,5 h');
    expect(texte(f)).toContain('modifications non enregistrées');
    bouton(f, 'Soumettre au visa').click();
    await attendre();
    const put = http.expectOne((r) => r.url === URL_FICHE && r.method === 'PUT');
    expect(put.request.body).toEqual({
      sequences: [{ titre: 'Lois de l’électricité', contenu: 'Loi d’Ohm', competences: null, heuresPrevues: 12.5, semaineDebut: null }],
    });
    const seq = { ordre: 1, titre: 'Lois de l’électricité', contenu: 'Loi d’Ohm', competences: null, heuresPrevues: 12.5, semaineDebut: null, heuresRealisees: 0, seances: 0 };
    put.flush(fiche({ id: 'fp1', statut: 'BROUILLON', sequences: [seq], heuresPrevues: 12.5 }));
    await attendre();
    http.expectOne(`${URL_FICHE}/soumission`).flush(
      fiche({ id: 'fp1', statut: 'SOUMISE', sequences: [seq], heuresPrevues: 12.5, soumiseLe: '2026-10-03T10:00:00Z', modifiable: false }),
    );
    await attendre();
    const t = texte(f);
    expect(t).toContain('Progression soumise au visa du chef des travaux.');
    expect(t).toContain('en attente du visa');
    expect(t).toContain('1. Lois de l’électricité');
  });

  it('chef des travaux : renvoie la fiche avec un commentaire obligatoire', async () => {
    await session(http, 'CHEF_TRAVAUX');
    const f = TestBed.createComponent(FicheProgressionPage);
    f.componentRef.setInput('classeId', 'c1');
    f.componentRef.setInput('matiereId', 'm-elec');
    f.detectChanges();
    await attendre();
    const seq = { ordre: 1, titre: 'Lois', contenu: null, competences: 'C1', heuresPrevues: 10, semaineDebut: '2026-10-05', heuresRealisees: 4, seances: 2 };
    http.expectOne(URL_FICHE).flush(fiche({ id: 'fp1', statut: 'SOUMISE', sequences: [seq], heuresPrevues: 10, soumiseLe: '2026-10-03T10:00:00Z', auteur: false, modifiable: false, visable: true, avancement: { heuresRealisees: 5.5, heuresHorsSequence: 1.5, seances: 3, derniereSeance: '2026-10-02' } }));
    await attendre();
    expect(texte(f)).toContain('4 h faites / 10 h · à partir du 05/10/2026');
    expect(texte(f)).toContain('5,5 h faites sur 10 h prévues · 3 séance(s), la dernière le 02/10/2026 · dont 1,5 h hors séquence');
    expect(texte(f)).toContain('Lire le cahier de textes');
    bouton(f, 'Renvoyer').click();
    await attendre();
    expect(texte(f)).toContain("Dites à l'enseignant ce qu'il faut revoir.");
    await saisir(f, '#commentaire', 'Ajoutez les TP d’atelier');
    bouton(f, 'Renvoyer').click();
    await attendre();
    const visa = http.expectOne(`${URL_FICHE}/visa`);
    expect(visa.request.body).toEqual({ accepte: false, commentaire: 'Ajoutez les TP d’atelier' });
    visa.flush(fiche({ id: 'fp1', statut: 'A_REVOIR', sequences: [seq], viseLe: '2026-10-03T11:00:00Z', visePar: 'OUEDRAOGO Salif', commentaireVisa: 'Ajoutez les TP d’atelier', modifiable: false }));
    await attendre();
    const t = texte(f);
    expect(t).toContain('renvoyée à l\'enseignant');
    expect(t).toContain('À revoir (OUEDRAOGO Salif');
  });

  it('suivi : fiches à viser et non commencées', async () => {
    await session(http, 'CHEF_TRAVAUX', true);
    const f = TestBed.createComponent(SuiviProgressionsPage);
    f.detectChanges();
    await attendre();
    http.expectOne('/api/v1/annees/a1/progressions').flush([
      ligne('2nde F3', 'ELEC', 'SOUMISE', 4), ligne('2nde F3', 'DESSIN', null), ligne('1re F3', 'ELEC', 'VISEE', 5), ligne('1re F3', 'ATELIER', 'BROUILLON', 1),
    ]);
    await attendre();
    const tuiles = [...(f.nativeElement as HTMLElement).querySelectorAll('.chiffres strong')].map((x) => x.textContent?.trim());
    expect(tuiles).toEqual(['1', '1', '1', '1', '0']); // dernière : en retard (v0.48.1)
    expect(texte(f)).toContain('Matières techniques et pratiques');
    bouton(f, 'À viser').click();
    f.detectChanges();
    const titres = [...(f.nativeElement as HTMLElement).querySelectorAll('section h2')].map((h) => h.textContent?.trim());
    expect(titres).toEqual(['2nde F3']);
    expect(texte(f)).toContain('4 séquence(s) · 16 h faites / 40 h prévues');
    expect(texte(f)).toContain("cahier tenu jusqu'au 02/10/2026");
  });

  it('visa mensuel (v0.47) : tableau du mois, puis visa d’un cahier qui se fige', async () => {
    expect(libelleMois('2026-10')).toBe('octobre 2026');
    expect(moisCourant(new Date('2026-12-31T23:00:00Z'))).toBe('2026-12');
    await session(http, 'CENSEUR', true);
    const f = TestBed.createComponent(CahiersVisasPage);
    f.detectChanges();
    await attendre();
    const suivi = http.expectOne((r) => r.url === '/api/v1/annees/a1/cahiers-textes');
    expect(suivi.request.params.get('mois')).toBe(moisCourant());
    suivi.flush([
      { classeId: 'c1', classeCode: '6e A', matiereId: 'm1', matiereLibelle: 'Mathématiques', domaine: 'GENERAL', enseignant: 'SANOU Paul', mois: '2026-10', seances: 8, vise: true, visePar: 'ZONGO Ines', viseLe: '2026-10-31T10:00:00Z' },
      { classeId: 'c1', classeCode: '6e A', matiereId: 'm2', matiereLibelle: 'Français', domaine: 'GENERAL', enseignant: 'KABORE Awa', mois: '2026-10', seances: 6, vise: false, visePar: null, viseLe: null },
      { classeId: 'c2', classeCode: '6e B', matiereId: 'm1', matiereLibelle: 'Mathématiques', domaine: 'GENERAL', enseignant: null, mois: '2026-10', seances: 0, vise: false, visePar: null, viseLe: null },
    ]);
    await attendre();
    const t = texte(f);
    expect(t).toContain('1 cahier(s) visé(s) sur 3 · 1 à viser · 1 sans séance notée');
    expect(t).toContain('ZONGO Ines');
    f.destroy();

    const g = TestBed.createComponent(CahierLecturePage);
    g.componentRef.setInput('classeId', 'c1');
    g.componentRef.setInput('matiereId', 'm2');
    g.detectChanges();
    await attendre();
    http.expectOne('/api/v1/classes/c1/matieres/m2/cahier-textes').flush([
      { id: 's1', classeId: 'c1', matiereId: 'm2', date: '2026-10-05', heureDebut: '08:00:00', heureFin: '10:00:00', heures: 2, sequenceOrdre: null, sequenceTitre: null, contenu: 'Dictée', travailAFaire: null, saisiLe: '', modifieLe: '' },
    ]);
    http.expectOne('/api/v1/classes/c1/matieres/m2/cahier-textes/visas').flush([]);
    await attendre();
    expect(texte(g)).toContain('Aucun mois visé.');
    await saisir(g, '#mois', '2026-10');
    await saisir(g, '#observation', 'Rythme conforme');
    bouton(g, 'Viser').click();
    await attendre();
    const visa = http.expectOne('/api/v1/classes/c1/matieres/m2/cahier-textes/visas');
    expect(visa.request.body).toEqual({ mois: '2026-10', observation: 'Rythme conforme' });
    visa.flush({ id: 'v1', classeId: 'c1', matiereId: 'm2', mois: '2026-10', seances: 1, observation: 'Rythme conforme', visePar: 'ZONGO Ines', viseLe: '2026-10-31T10:00:00Z' });
    await attendre();
    expect(texte(g)).toContain("Cahier visé pour octobre 2026 (1 séance(s)) : ce mois ne peut plus être modifié par l'enseignant.");
    expect(texte(g)).toContain('octobre 2026 · 1 séance(s) · ZONGO Ines');
  });
});
